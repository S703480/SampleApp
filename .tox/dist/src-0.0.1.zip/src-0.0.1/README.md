create new environment
activate the created environment
create all required files
Install required files
